--"INTEL CONFIDENTIAL"
--Copyright 2016 Intel Corporation All Rights Reserved.
--
--The source code contained or described herein and all documents related to the source code ("Material") are owned by Intel Corporation or its suppliers or licensors. Title to the Material remains with Intel Corporation or its suppliers and licensors. The Material contains trade secrets and proprietary and confidential information of Intel or its suppliers and licensors. The Material is protected by worldwide copyright and trade secret laws and treaty provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded, posted, transmitted, distributed, or disclosed in any way without Intel's prior express written permission.
--
--No license under any patent, copyright, trade secret or other intellectual property right is granted to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication, inducement, estoppel or otherwise. Any license under such intellectual property rights must be express and approved by Intel in writing.

-- TASK:
-- Customer segmentation analysis: Customers are separated along the
-- following key shopping dimensions: recency of last visit, frequency of visits and
-- monetary amount. Use the store and online purchase data during a given year
-- to compute. After model of separation is build, 
-- report for the analysed customers to which "group" they where assigned

-- IMPLEMENTATION NOTICE:
-- hive provides the input for the clustering program
-- The input format for the clustering is:
--   customer ID, 
--   flag if customer bought something within the last 60 days (integer 0 or 1), 
--   number of orders, 
--   total amount spent



-- ss_sold_date_sk > 2002-01-02
DROP TABLE IF EXISTS ${hiveconf:TEMP_TABLE};
CREATE TABLE ${hiveconf:TEMP_TABLE} (
  cid               BIGINT,
  frequency         BIGINT,
  most_recent_date  BIGINT,
  amount            decimal(15,2)
);

-- Add store sales data
INSERT INTO TABLE ${hiveconf:TEMP_TABLE}
SELECT
  ss_customer_sk                     AS cid,
  count(distinct ss_ticket_number)   AS frequency,
  max(ss_sold_date_sk)               AS most_recent_date,
  SUM(ss_net_paid)                   AS amount
FROM store_sales ss
JOIN date_dim d ON ss.ss_sold_date_sk = d.d_date_sk
WHERE d.d_date > '${hiveconf:q25_date}'
AND ss_customer_sk IS NOT NULL
GROUP BY ss_customer_sk
;

-- Add web sales data
INSERT INTO TABLE ${hiveconf:TEMP_TABLE}
SELECT
  ws_bill_customer_sk             AS cid,
  count(distinct ws_order_number) AS frequency,
  max(ws_sold_date_sk)            AS most_recent_date,
  SUM(ws_net_paid)                AS amount
FROM web_sales ws
JOIN date_dim d ON ws.ws_sold_date_sk = d.d_date_sk
WHERE d.d_date > '${hiveconf:q25_date}'
AND ws_bill_customer_sk IS NOT NULL
GROUP BY ws_bill_customer_sk
;

-- This query requires parallel order by for fast and deterministic global ordering of final result
set hive.optimize.sampling.orderby=${hiveconf:bigbench.hive.optimize.sampling.orderby};
set hive.optimize.sampling.orderby.number=${hiveconf:bigbench.hive.optimize.sampling.orderby.number};
set hive.optimize.sampling.orderby.percent=${hiveconf:bigbench.hive.optimize.sampling.orderby.percent};
--debug print
set hive.optimize.sampling.orderby;
set hive.optimize.sampling.orderby.number;
set hive.optimize.sampling.orderby.percent;


--ML-algorithms expect double values as input for their Vectors. 
DROP TABLE IF EXISTS ${hiveconf:TEMP_RESULT_TABLE};
CREATE TABLE ${hiveconf:TEMP_RESULT_TABLE} (
  cid        BIGINT,--used as "label", all following values are used as Vector for ML-algorithm
  recency    double,
  frequency  double,
  totalspend double
);


INSERT INTO TABLE ${hiveconf:TEMP_RESULT_TABLE}
SELECT
  -- rounding of values not necessary
  cid            AS cid,
  CASE WHEN 37621 - max(most_recent_date) < 60 THEN 1.0 ELSE 0.0 END 
                 AS recency, -- 37621 == 2003-01-02
  SUM(frequency) AS frequency, --total frequency
  SUM(amount)    AS totalspend --total amount
FROM ${hiveconf:TEMP_TABLE}
GROUP BY cid 
--CLUSTER BY cid --cluster by preceded by group by is silently ignored by hive but fails in spark
--no total ordering with ORDER BY required, further processed by clustering algorithm
ORDER BY cid
;


--- CLEANUP--------------------------------------------
DROP TABLE ${hiveconf:TEMP_TABLE};
